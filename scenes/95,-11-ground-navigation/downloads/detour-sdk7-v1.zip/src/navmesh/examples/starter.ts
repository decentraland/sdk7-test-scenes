import { openNavigation } from '../runtime.mjs'
import mesh from './mesh'
import { mountTwoFloorExample } from './two-floors'

export function startNavigationExample() {
  return mountTwoFloorExample(openNavigation, mesh)
}
