import type { OpenNavigation } from './types'
export declare const openNavigation: OpenNavigation
