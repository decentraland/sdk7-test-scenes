// Auto-generated entity names from the scene


/**
 * Object containing all entity names in the scene for autocomplete support.
 */
export enum EntityNames {
  Ground = "Ground",
  Tile_1 = "Tile 1",
} 
